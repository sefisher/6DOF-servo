import sys
#!/usr/bin/env python3
"""
ODrive Gui
"""

from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QApplication,QDialog, QTabWidget
from PyQt5.uic import loadUi
from PyQt5.QtCore import *
from PyQt5.QtGui import *

import odrive

from odrive.enums import *

import time

import math


		print("reboot...")
		my_drive.reboot()
		sys.exit(app.exec())




