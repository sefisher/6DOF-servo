# Odrive_Gui
Odrive gui install:

install PyQt5 in Anaconda Prompt:

`pip3 install pyqt5`

start:

`python main.py` or `Start-Odrive-GUI.bat`

issue:

`File "main.py", line 7, in <module>
 from PyQt5.QtCore import pyqtSlot
ImportError: DLL load failed: The specified module could not be found.`

Update anaconda:
`conda update --all`
if conda is in your PATH...
